package edu.rice.comp322;

public class AutoGraderExample {
  public int sum(int a, int b) {
    return a + b;
  }

  public int dbl(int a) {
    return 2 * a;
  }

  public int triple(int a) {
    return 4 * a; // deliberately broken
  }

  public int mult(int a, int b) {
    return a / b; // deliberately broken
  }
}
